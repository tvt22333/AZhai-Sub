<?php

$config = require __DIR__ . '/../config.php';

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$pageTitle = '管理后台';

$pdo = db();

$totalUsers = (int)$pdo->query(
    "SELECT COUNT(*) FROM users"
)->fetchColumn();

$totalDomains = (int)$pdo->query(
    "SELECT COUNT(*) FROM domains"
)->fetchColumn();

$activeDomains = (int)$pdo->query(
    "SELECT COUNT(*) FROM domains WHERE status = 'active'"
)->fetchColumn();

$pendingApplications = (int)$pdo->query(
    "SELECT COUNT(*) FROM domain_applications WHERE status = 'pending'"
)->fetchColumn();

$totalRecords = (int)$pdo->query(
    "SELECT COUNT(*) FROM domain_records"
)->fetchColumn();

$totalProviders = (int)$pdo->query(
    "SELECT COUNT(*) FROM dns_providers"
)->fetchColumn();


$recentUsers = $pdo->query("
    SELECT
        id,
        username,
        email,
        status,
        created_at
    FROM users
    ORDER BY id DESC
    LIMIT 8
")->fetchAll();


$recentApplications = $pdo->query("
    SELECT
        da.id,
        da.user_id,
        da.provider_domain_id,
        da.subdomain,
        da.reason,
        da.status,
        da.created_at,
        u.username,
        dpd.domain AS provider_domain
    FROM domain_applications da
    LEFT JOIN users u
        ON u.id = da.user_id
    LEFT JOIN dns_provider_domains dpd
        ON dpd.id = da.provider_domain_id
    ORDER BY da.id DESC
    LIMIT 8
")->fetchAll();

require __DIR__ . '/../includes/admin_header.php';

?>

<div class="admin-dashboard">

    <div class="admin-welcome">
        <h1>AZhai Sub 管理后台</h1>
        <p>管理用户、域名、DNS 服务商以及域名申请。</p>
    </div>


    <div class="stats-grid">

        <div class="stat-card">
            <div class="stat-title">用户数量</div>
            <div class="stat-number"><?= $totalUsers ?></div>
            <div class="stat-desc">注册用户</div>
        </div>

        <div class="stat-card">
            <div class="stat-title">域名数量</div>
            <div class="stat-number"><?= $totalDomains ?></div>
            <div class="stat-desc">已申请域名</div>
        </div>

        <div class="stat-card">
            <div class="stat-title">正常域名</div>
            <div class="stat-number"><?= $activeDomains ?></div>
            <div class="stat-desc">当前正在使用</div>
        </div>

        <div class="stat-card">
            <div class="stat-title">待审核</div>
            <div class="stat-number"><?= $pendingApplications ?></div>
            <div class="stat-desc">等待管理员处理</div>
        </div>

        <div class="stat-card">
            <div class="stat-title">DNS 记录</div>
            <div class="stat-number"><?= $totalRecords ?></div>
            <div class="stat-desc">A / AAAA / CNAME / TXT</div>
        </div>

        <div class="stat-card">
            <div class="stat-title">DNS 服务商</div>
            <div class="stat-number"><?= $totalProviders ?></div>
            <div class="stat-desc">Cloudflare / 阿里云</div>
        </div>

    </div>


    <div class="admin-card">

        <h2>快捷操作</h2>

        <div class="quick-actions">

            <a href="/admin/applications.php">
                <strong>域名审核</strong>
                <br>
                <small>处理域名申请</small>
            </a>

            <a href="/admin/domains.php">
                <strong>域名管理</strong>
                <br>
                <small>管理所有域名</small>
            </a>

            <a href="/admin/users.php">
                <strong>用户管理</strong>
                <br>
                <small>管理注册用户</small>
            </a>

            <a href="/admin/providers.php">
                <strong>DNS 服务商</strong>
                <br>
                <small>管理 DNS API</small>
            </a>

            <a href="/admin/logs.php">
                <strong>操作日志</strong>
                <br>
                <small>查看操作记录</small>
            </a>

        </div>

    </div>


    <br>


    <div class="admin-grid">


        <div class="admin-card">

            <h2>最新用户</h2>

            <?php if (!$recentUsers): ?>

                <p>暂无用户。</p>

            <?php else: ?>

                <table class="admin-table">

                    <thead>
                    <tr>
                        <th>用户名</th>
                        <th>邮箱</th>
                        <th>状态</th>
                    </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($recentUsers as $user): ?>

                        <?php
                        $userStatus = [
                            'active' => '正常',
                            'disabled' => '已禁用'
                        ];

                        $status = $user['status'];
                        ?>

                        <tr>

                            <td>
                                <?= e($user['username']) ?>
                            </td>

                            <td>
                                <?= e($user['email']) ?>
                            </td>

                            <td>

                                <span class="status status-<?= e($status) ?>">
                                    <?= e($userStatus[$status] ?? $status) ?>
                                </span>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            <?php endif; ?>

        </div>


        <div class="admin-card">

            <h2>最新域名申请</h2>

            <?php if (!$recentApplications): ?>

                <p>暂无申请。</p>

            <?php else: ?>

                <table class="admin-table">

                    <thead>
                    <tr>
                        <th>域名</th>
                        <th>用户</th>
                        <th>状态</th>
                    </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($recentApplications as $application): ?>

                        <?php

                        $applicationStatus = [
                            'pending' => '待审核',
                            'approved' => '已通过',
                            'rejected' => '已拒绝'
                        ];

                        $status = $application['status'];

                        ?>

                        <tr>

                            <td>
    <?php
    $rootDomain = trim(
        (string)(
            $application['provider_domain']
            ?? ''
        )
    );

    if ($rootDomain === '') {
        $rootDomain = trim(
            (string)(
                $config['base_domain']
                ?? ''
            )
        );
    }

    $rootDomain = strtolower(
        rtrim(
            $rootDomain,
            '.'
        )
    );

    $subdomain = trim(
        (string)(
            $application['subdomain']
            ?? ''
        )
    );

    if (
        $subdomain !== ''
        &&
        $rootDomain !== ''
    ) {
        $displayDomain =
            $subdomain .
            '.' .
            $rootDomain;
    } else {
        $displayDomain = '-';
    }
    ?>

    <?= e($displayDomain) ?>
</td>

                            <td>
                                <?= e($application['username'] ?? '-') ?>
                            </td>

                            <td>

                                <span class="status status-<?= e($status) ?>">
                                    <?= e($applicationStatus[$status] ?? $status) ?>
                                </span>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            <?php endif; ?>

        </div>

    </div>

</div>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>